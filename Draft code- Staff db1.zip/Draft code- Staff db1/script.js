
const API_URL = "http://localhost:3000/api/staff/dashboard";

// Obtain JWT token after staff login.
// Replace this with your actual authentication implementation.
const token = localStorage.getItem("staffToken");

let dashboardData = null;

// Retrieve shared database information
async function loadDashboard() {

    try {

        const response = await fetch(API_URL, {
            method: "GET",
            headers: {
                "Authorization": `Bearer ${token}`,
                "Content-Type": "application/json"
            }
        });

        if (!response.ok) {
            throw new Error("Unable to retrieve dashboard data.");
        }

        dashboardData = await response.json();

        displayStatistics();
        displayAppointments();
        displayCustomers();
        displayVehicles();
        displayServices();
        displayMaintenance();

    } catch (error) {

        console.error(error);

        document.getElementById("pageTitle").textContent =
            "Unable to load dashboard. Check your API connection.";

    }
}

// Display dashboard statistics
function displayStatistics() {

    const counts = dashboardData.counts;

    document.getElementById("totalBookings").textContent =
        counts.totalAppointments;

    document.getElementById("pendingBookings").textContent =
        counts.pendingAppointments;

    document.getElementById("completedServices").textContent =
        counts.completedServices;

    document.getElementById("ongoingServices").textContent =
        counts.ongoingServices;
}

// Display appointments
function displayAppointments() {

    const appointments = dashboardData.appointments;

    const rows = appointments.map(a => `
        <tr>
            <td>${a.customer}</td>
            <td>${a.registration_no}</td>
            <td>${formatDate(a.appointment_date)}</td>
            <td>${a.service_type}</td>
            <td>${a.status}</td>
        </tr>
    `).join("");

    document.getElementById("recentAppointments").innerHTML = rows;
    document.getElementById("appointmentTable").innerHTML =
        appointments.map(a => `
            <tr>
                <td>${a.id}</td>
                <td>${a.customer}</td>
                <td>${a.registration_no}</td>
                <td>${formatDate(a.appointment_date)}</td>
                <td>${a.service_type}</td>
                <td>${a.status}</td>
            </tr>
        `).join("");
}

// Display customers
function displayCustomers() {

    document.getElementById("customerTable").innerHTML =
        dashboardData.customers.map(c => `
            <tr>
                <td>${c.id}</td>
                <td>${c.name}</td>
                <td>${c.email}</td>
                <td>${c.phone || "-"}</td>
            </tr>
        `).join("");
}

// Display vehicles
function displayVehicles() {

    document.getElementById("vehicleTable").innerHTML =
        dashboardData.vehicles.map(v => `
            <tr>
                <td>${v.registration_no}</td>
                <td>${v.owner}</td>
                <td>${v.make}</td>
                <td>${v.model}</td>
                <td>${v.year}</td>
            </tr>
        `).join("");
}

// Display service records
function displayServices() {

    document.getElementById("serviceTable").innerHTML =
        dashboardData.services.map(s => `
            <tr>
                <td>${s.id}</td>
                <td>${s.registration_no}</td>
                <td>${s.service_type}</td>
                <td>${formatDate(s.service_date)}</td>
                <td>$${Number(s.cost).toFixed(2)}</td>
                <td>${s.status}</td>
            </tr>
        `).join("");
}

// Display maintenance reminders
function displayMaintenance() {

    document.getElementById("maintenanceTable").innerHTML =
        dashboardData.reminders.map(m => `
            <tr>
                <td>${m.registration_no}</td>
                <td>${m.reminder}</td>
                <td>${formatDate(m.due_date)}</td>
                <td>${m.status}</td>
            </tr>
        `).join("");
}

// Change dashboard pages
function showPage(page) {

    document.querySelectorAll(".page").forEach(section => {
        section.classList.add("hidden");
    });

    document.getElementById(page).classList.remove("hidden");

    document.getElementById("pageTitle").textContent =
        page.charAt(0).toUpperCase() + page.slice(1);
}

function formatDate(value) {
    if (!value) return "-";

    const date = new Date(value);

    return isNaN(date)
        ? value
        : date.toLocaleDateString("en-SG");
}

function logout() {
    localStorage.removeItem("staffToken");
    window.location.reload();
}

// Load dashboard when page opens
loadDashboard();
